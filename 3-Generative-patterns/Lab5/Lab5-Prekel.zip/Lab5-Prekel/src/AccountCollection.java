import java.util.ArrayList;

public class AccountCollection extends ArrayList<Account> {
}
