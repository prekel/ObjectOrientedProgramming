public class AbstractBuilder<T> {
    protected T result;

    public T getResult() {
        return result;
    }
}
