#ifndef DECLARATIONS_H
#define DECLARATIONS_H

class Department;

class HeadOfDepartment;

class Person;

class Student;

class Teacher;

#endif //DECLARATIONS_H
